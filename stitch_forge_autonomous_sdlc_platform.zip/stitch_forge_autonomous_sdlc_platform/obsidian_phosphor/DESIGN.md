---
name: Obsidian Phosphor
colors:
  surface: '#0b1512'
  surface-dim: '#0b1512'
  surface-bright: '#313b38'
  surface-container-lowest: '#06100d'
  surface-container-low: '#141e1a'
  surface-container: '#18221e'
  surface-container-high: '#222c29'
  surface-container-highest: '#2d3733'
  on-surface: '#dae5e0'
  on-surface-variant: '#c2caaf'
  inverse-surface: '#dae5e0'
  inverse-on-surface: '#28332f'
  outline: '#8c947c'
  outline-variant: '#424935'
  surface-tint: '#95da1b'
  primary: '#ffffff'
  on-primary: '#213600'
  primary-container: '#b0f73d'
  on-primary-container: '#496f00'
  inverse-primary: '#446900'
  secondary: '#5bdf88'
  on-secondary: '#003919'
  secondary-container: '#06a657'
  on-secondary-container: '#003115'
  tertiary: '#ffffff'
  on-tertiary: '#452b00'
  tertiary-container: '#ffddb3'
  on-tertiary-container: '#8a5b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b0f73d'
  primary-fixed-dim: '#95da1b'
  on-primary-fixed: '#121f00'
  on-primary-fixed-variant: '#324f00'
  secondary-fixed: '#79fca2'
  secondary-fixed-dim: '#5bdf88'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005228'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#ffb94f'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#0b1512'
  on-background: '#dae5e0'
  surface-variant: '#2d3733'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Space Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.12em
  code-dense:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

## Brand & Style

This design system expresses a high-velocity, industrial retro-futurism tailored for autonomous multi-agent software engineering. Borrowing heavily from late 1970s and 1980s aerospace interfaces, CRT teletext displays, and cold-war military telemetry terminals, it balances vintage hardware nostalgia with the hyper-dense information architecture required by modern engineering runtimes.

The emotional signature is precise, authoritative, and computational. Rather than simulating a decaying, low-fidelity CRT novelty, the aesthetic treats vintage computing paradigms as high-efficiency functional instrumentation: deep subterranean greens, phosphor beam highlights, tactile panel enclosures, glowing telemetry indicators, and strict mechanical grid alignments. Visual hierarchy relies on razor-thin 1px technical structural borders, high-contrast monospace metadata arrays, and neon phosphor accents that demand direct operator intervention.

## Colors

The palette operates strictly within a deep terminal phosphor ecosystem:

- **Background Canvas (`#080F0D`):** Deep obsidian terminal green-black. Used for the foundational viewport background and inset console sinks.
- **Primary Surface (`#101A17`):** Base structural container color for sidebars, system toolbars, and inactive deck regions.
- **Elevated Panels (`#15221D`):** Active interactive cards, floating command palettes, telemetry modules, and modal overlays.
- **Neon Phosphor Accent (`#B7FF45`):** Primary action callouts, affirmative system events, high-confidence agent decisions, and targeted interactive selections.
- **Terminal Phosphor Green (`#65E890`):** Secondary informational streams, terminal output stdout, verified test routines, and live telemetry tracking.
- **Warm Amber (`#FFB84A`):** Consensus locks, review-required flags, linting alerts, agent arbitration state, and non-blocking warnings.
- **Error / Fault Red (`#FF6868`):** Unhandled runtime exceptions, failed assertions, deadlocks, and system-level aborts.
- **Structural Borders & Dividers (`#283B32`):** Low-contrast structural lines that partition panels, module frames, and data cells without introducing visual clutter.
- **Primary Typography (`#E7F1E9`):** High-readability bone-white with faint green undertones for primary interface copy, header tags, and execution readouts.
- **Muted Typography (`#91A69A`):** Low-priority metadata, timestamps, dormant node tags, and code comments.

## Typography

The type system creates an intentional friction between bold, geometric modernist headers (`Space Grotesk`) and clinical, monospaced computational syntax (`Space Mono`).

- **Display & Headlines:** Headings use `Space Grotesk` with tight negative letter-spacing to emphasize authority, industrial structure, and clear system modules.
- **Body & Log Runs:** Interface copy, multi-agent dialogue, stack traces, and system metrics utilize `Space Mono` to guarantee tabular spatial integrity, alignment of code columns, and unambiguous character delineation.
- **Labels & Micro-Badges:** Uppercase monospace tracking is mandatory for labels (`label-md`, `label-sm`), system states, status tickers, and architecture IDs.

## Layout & Spacing

Layouts adhere to an engineering control dashboard architecture: dense, high-throughput, and split into interlocking multi-window telemetry panes.

- **Grid Strategy:** A desktop-first 12-column fluid grid system pinned to a maximum canvas constraint or stretched edge-to-edge for multi-monitor workstations.
- **Rhythm & Structure:** Panel gutters (`1.5rem` on desktop, `1rem` on mobile) separate independent agent nodes, terminal consoles, and architecture diagrams.
- **Component Density:** Dense component padding uses the tight `0.25rem` to `0.75rem` scale to optimize vertical space within execution streams and trace outputs.
- **Responsive Handling:** Desktop interfaces sustain three concurrent panels (Agent Graph / Active Session / Console Output). At tablet widths (`<1024px`), layouts collapse to dual panels with sliding drawer logs. Mobile viewports (`<768px`) collapse into a single active panel with pinned bottom navigation tabs.

## Elevation & Depth

Depth is defined through planar surface stacking, 1px perimeter outlines, and radiant phosphor ambient glow rather than standard drop shadows.

- **Panel Hierarchy:** Base canvas (`#080F0D`) holds recessed log viewports and background graphs. Inset panels sit at `#101A17`. Interactive active surfaces lift to `#15221D`.
- **1px Technical Framing:** Every floating panel, modal, and badge uses a clean `1px solid #283B32` perimeter border to evoke hardware circuit modularity.
- **Phosphor Bloom:** Focused elements, active agent nodes, and active input panels project a subtle ambient glow: `0 0 16px -2px rgba(183, 255, 69, 0.18)` for neon phosphor elements and `0 0 16px -2px rgba(255, 184, 74, 0.20)` for amber consensus states.
- **Scanline & CRT Texture Overlays:** Console monitors and code views deploy an ultra-faint repeating horizontal raster line mask (`linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%)`, background-size `100% 4px`) with pointer-events disabled.

## Shapes

The shape system adopts a minimal corner radius (`0.25rem` for standard elements, `0.5rem` for primary outer panels) reflecting precision hardware cutouts and chamfered industrial chassis.

- **Corners:** Maintain tight, near-orthogonal geometry across buttons, panels, tooltips, and data grids. Roundedness level `1` prevents the interface from feeling playfully rounded while eliminating severe brutalist sharp points.
- **Micro-Badges & Telemetry Nodes:** Badges, status LEDs, and tag containers use squared-off or chamfered edges with zero to 2px radiuses, cementing the vintage instrumentation look.

## Components

### Buttons & Interactive Controls
- **Primary Buttons:** High-contrast phosphor blocks (`background: #B7FF45`, `color: #080F0D`, font: `Space Mono` bold, all-caps). On hover: bright phosphor bloom (`box-shadow: 0 0 12px rgba(183, 255, 69, 0.4)`).
- **Secondary / Ghost Buttons:** Inset surface (`#101A17`) with 1px border (`#283B32`), text (`#E7F1E9`). On hover: border transitions to `#65E890`, text shifts to neon phosphor.
- **Terminal Actions:** Compact monospace trigger lines prefixed with `[ RUN ]`, `[ FORK ]`, or `[ ABORT ]`.

### Monospace Tabs & Pill Selectors
- **Tab Rails:** Inset dark horizontal bar with tabs separated by 1px vertical borders. Inactive tabs display muted text (`#91A69A`). Active tab receives a `#15221D` background with an accented 2px top neon phosphor bar (`#B7FF45`) and illuminated primary text.

### Terminal Logs & Stream Consoles
- **Viewport:** Recessed `#080F0D` base with scanline raster overlay. Monospace typography (`code-dense`) with timestamps in muted green (`#91A69A`), source agents in neon phosphor (`#B7FF45`), and payload outputs in clean terminal green (`#65E890`).
- **Telemetry Indicators (LEDs):** 6px circular nodes with radial glowing diffusion. Green (`#B7FF45`) for running processes, Amber (`#FFB84A`) for waiting/arbitration, Red (`#FF6868`) for unhandled crash events.

### Input Fields & Command Prompts
- **Terminal Inputs:** Flat `#101A17` container with 1px border (`#283B32`). Prefixed by terminal prompts (`FORGE://> `). Focus states shift border to `#65E890` with an animated solid block cursor (`▋`).

### Agent Avatar Badges & Node Cards
- **Agent Cards:** Outlined container (`#15221D`) featuring an agent identity block: a tiny pixelated matrix badge, model identifier tag (`AGENT_CLAUDE_CORE // v3.5`), execution state LED, and real-time token/latency monitors in tabular monospace figures.
- **Selection State:** Active agent cards switch perimeter borders from `#283B32` to `#B7FF45` with subtle background shifts and a phosphor drop-edge glow.

### Checkboxes & Segmented Toggles
- **Toggles:** Square segmented boxes marked by an internal crosshair (`[ X ]` or `[   ]`) powered by CSS styling, preserving authentic monospaced console aesthetics across all standard HTML form controls.