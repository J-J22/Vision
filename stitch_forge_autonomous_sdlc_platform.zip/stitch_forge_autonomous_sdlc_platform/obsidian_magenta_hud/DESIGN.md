---
name: Obsidian Magenta HUD
colors:
  surface: '#1b1018'
  surface-dim: '#1b1018'
  surface-bright: '#43353f'
  surface-container-lowest: '#150b13'
  surface-container-low: '#231821'
  surface-container: '#281c25'
  surface-container-high: '#33262f'
  surface-container-highest: '#3e313a'
  on-surface: '#f2dde9'
  on-surface-variant: '#e5bcc5'
  inverse-surface: '#f2dde9'
  inverse-on-surface: '#392d36'
  outline: '#ac878f'
  outline-variant: '#5c3f46'
  surface-tint: '#ffb1c4'
  primary: '#ffb1c4'
  on-primary: '#65002e'
  primary-container: '#ff4a8d'
  on-primary-container: '#590028'
  inverse-primary: '#ba005b'
  secondary: '#ffb1c2'
  on-secondary: '#66002b'
  secondary-container: '#da0566'
  on-secondary-container: '#fff1f2'
  tertiary: '#00dbe9'
  on-tertiary: '#00363a'
  tertiary-container: '#00a0aa'
  on-tertiary-container: '#002f33'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e1'
  primary-fixed-dim: '#ffb1c4'
  on-primary-fixed: '#3f001a'
  on-primary-fixed-variant: '#8f0044'
  secondary-fixed: '#ffd9e0'
  secondary-fixed-dim: '#ffb1c2'
  on-secondary-fixed: '#3f0018'
  on-secondary-fixed-variant: '#8f0040'
  tertiary-fixed: '#7df4ff'
  tertiary-fixed-dim: '#00dbe9'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#1b1018'
  on-background: '#f2dde9'
  surface-variant: '#3e313a'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.625rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Geist
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.05em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.08em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.1em
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system channels an aggressive, hyper-focused cyberpunk CRT terminal aesthetic built for low-light, high-throughput operator environments. It pairs deep plum-obsidian and nocturnal maroon chassis with blinding neon hot pinks, electric magenta, and crisp spectral cyan micro-accents. 

The stylistic execution merges **Cyberpunk Brutalism** with **Tactical Terminal HUD** conventions:
- High-density information architecture with zero wasted whitespace.
- Sharp, technical borders, hairline division grids, and monospaced diagnostic readouts.
- Controlled phosphor glow and luminous edge highlights that imply active cathode-ray tube or holographic glass projection without degrading legibility.
- Strict visual hierarchy that commands urgency, surgical precision, and unyielding speed.

## Colors

The palette operates in high-contrast luminescence against light-absorbing void surfaces:

- **Primary Accent (`#FF007F`)**: Laser magenta / hot neon pink. Reserved for primary operational actions, active execution states, high-priority system telemetry, and critical navigation landmarks.
- **Secondary Accent (`#D80064`)**: Deep electric fuchsia/crimson. Used for secondary active indicators, mid-level alert boundaries, interactive states, and hover transitions.
- **Tertiary Accent (`#00F0FF`)**: Electric cyan. Deployed as a high-visibility micro-accent for auxiliary telemetry, connection statuses, syntax highlighting, and success state validation.
- **Neutral Base (`#120810`)**: Deep maroon / obsidian plum. The baseline terminal canvas. Layered upward through `#180915` (canvas elevated), `#1C0B18` (panels/surfaces), and `#260E21` (active toolbars/hovered containers).
- **Hairline Structural Borders (`#4A1238`, `#5E1848`)**: Strict 1px division rules providing structural geometry without washing out ambient black levels.
- **Text & Readability**: Crisp pure white (`#FFFFFF`) and spectral silver (`#F3E8EE`) for primary data output; desaturated plum-rose (`#BA98AF`, `#A88B9E`) for secondary labels, metadata, and timestamps.
- **Warning & Diagnostic Accents**: Neon Gold (`#FFD23F`) for warnings and resource throttles; pure Crimson (`#FF1744`) for critical system failure.

## Typography

The typographic hierarchy reinforces an electronic instrument display:
- **Headlines (Space Grotesk)**: Geometric, technical display styling with tight tracking. Headlines convey section architecture and tactical mission views.
- **Body & Continuous Text (Geist)**: Extremely readable, unembellished low-latency grotesk tailored for deep screen reading, rapid terminal logs, and system metrics.
- **Labels, Readouts & HUD Metrics (JetBrains Mono)**: Monospaced, zero-ambiguity characters equipped with tabular numbers. All operational indicators, tags, parameters, and timecodes must use uppercase tracking for machine-interface authenticity.

## Layout & Spacing

The layout is built upon an uncompromising, rigid 12-column tactical grid designed for high-density workspaces:

- **Desktop Breakpoints (1280px+)**: Multi-pane layout. 12-column fluid grid with `gutter-desktop` (1.5rem) and compact outer margins (2rem) maximizing viewport utilization. Left/right utility rails remain fixed while inner data tiles adapt.
- **Tablet Breakpoints (768px – 1279px)**: 8-column layout. Sidebar collapses to an icon-only dock; terminal output feeds collapse to vertical stacking.
- **Mobile Breakpoints (<768px)**: 4-column layout. Margins collapse to 1rem. Toolbars and command inputs dock to screen perimeters.

Spacing cadence is disciplined and compact (`space-xs` through `space-md`), rejecting expansive modern consumer padding in favor of maximum observable information density. Content containers utilize explicit 1px bounding lines rather than empty space to partition modules.

## Elevation & Depth

Depth is defined through luminosity tiers, crisp hairline structural borders, and electric phosphor diffusion—never blurry neutral drop shadows.

- **Floor 0 (Background)**: `#120810`. Raw CRT canvas. Optionally overlaid with a subtle 1px scanline effect or 2% SVG noise pattern.
- **Floor 1 (Panels & Windows)**: `#1C0B18`. 1px hairline border in `#4A1238`. 
- **Floor 2 (Floating Popovers & Terminals)**: `#260E21`. 1px hairline border in `#5E1848`, reinforced with a localized edge glow: `box-shadow: 0 0 16px -4px rgba(255, 0, 127, 0.25)`.
- **Floor 3 (Active Focus / Modal Layers)**: `#180915` overlay with 85% opacity backdrop blur (4px blur max to keep the gritty hardware feel). Active element outlines scale to `#FF007F` with a tight, electric bloom: `box-shadow: 0 0 10px 1px rgba(255, 0, 127, 0.45), inset 0 0 6px 0 rgba(255, 0, 127, 0.15)`.

## Shapes

The interface geometry is strictly **Sharp (0px roundedness)**:
- Windows, panels, tooltips, cards, buttons, and input fields all use crisp 90-degree right angles.
- Optional chamfered corners (angled cutouts at 45 degrees, 6px to 8px) may be applied to primary action trigger buttons and section headers to evoke military-grade physical hardware enclosures.
- Pill shapes, rounded bubbles, and soft radiuses are prohibited.

## Components

### Buttons & Triggers
- **Primary Action**: Solid `#FF007F` background with `#120810` bold text. On hover, background shifts to `#FF2A85` with an external edge glow (`0 0 14px rgba(255, 0, 127, 0.6)`). Active state applies a 1px inner inset.
- **Secondary / Ghost Action**: `#1C0B18` background, 1px border `#5E1848`, `#F3E8EE` text. On hover, border flashes `#FF007F` and text shifts to `#FFFFFF`.
- **System Destructive / Warning**: Background `#180915`, 1px border `#FF1744`, text `#FF1744`. Hover activates crimson bloom.
- **Labeling**: All button text must be set in `label-md` uppercase monospace with prominent letter-spacing.

### Data Cards & HUD Modules
- Containers render with `#1C0B18` surface and 1px `#4A1238` framing.
- Header bars feature technical brackets (e.g., `[SYS.MONITOR // 01]`) accompanied by a 2px top border accent in `#FF007F` or `#00F0FF`.
- Corner registration marks (`+` or 4px crosshairs) anchor card boundaries to mimic engineering drafts.

### Input Fields & Command Prompts
- Background `#120810`, bottom border 2px `#5E1848` (or full 1px box border).
- Text rendered in `code-inline` using `#FFFFFF`. Placeholder text rendered in muted `#A88B9E`.
- Focus state instantly replaces border with `#00F0FF` or `#FF007F`, introducing a persistent block cursor `█` with a 1Hz blink interval.

### Chips, Tags & Badges
- Micro-containers with 0px radius, 1px solid borders, and dense padding (`0.125rem 0.375rem`).
- **Telemetry Live**: `#00F0FF` border, text `#00F0FF`, background `rgba(0, 240, 255, 0.08)`.
- **Alert High**: `#FF007F` border, text `#FF007F`, background `rgba(255, 0, 127, 0.12)`.
- **Stby / Idle**: `#4A1238` border, text `#BA98AF`, background `#120810`.

### Checkboxes & Radios
- Checkboxes: Strict 14x14px square, 1px `#5E1848` border, `#120810` fill. Checked state renders a solid centered `#FF007F` square (8x8px) with a subtle neon bleed.
- Radio Buttons: Diamond orientation (square rotated 45 degrees) with a centered diamond pip when active.

### Lists & Telemetry Streams
- High-density rows separated by 1px dotted or solid `#260E21` dividers.
- Alternating row zebra fills: `#180915` and `#1C0B18`.
- Hover row state triggers a left 2px vertical neon spine in `#FF007F` and full-row brightness boost.

### Terminal Output & Log Viewer
- Embedded scrollable console modules with a fixed black-plum canvas (`#0E060D`).
- Scrollbars: 4px width, `#1C0B18` track, `#FF007F` solid thumb without radius.